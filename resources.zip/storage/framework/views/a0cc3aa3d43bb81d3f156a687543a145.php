<?php $__env->startSection('title', 'Welcome'); ?>
<?php $__env->startSection('body-class', 'page-welcome'); ?>

<?php $__env->startSection('content'); ?>
<div class="nexora-layout">
    <div class="grain-overlay"></div>

    <nav class="navbar-minimal">
        <div class="nav-left">
            <span class="brand-name">Bung Dasep</span>
        </div>
    </nav>

    <section class="welcome-hero">
        <div class="container hero-content">
            <h1 class="welcome-main-title">WELCOME</h1>
            
            <p class="welcome-desc">
                <span class="desc-left">Website ini lahir dari jeda—</span>
                <span class="desc-right">antara lelah, ingin tahu, dan keinginan untuk tetap hidup.</span>
            </p>

            <div class="welcome-actions">
                <a href="<?php echo e(url('/home')); ?>" class="btn-masuk">Mulai</a>
            </div>

            <div class="hero-illustration">
                </div>

            <div class="trusted-by">
                <p>Ruang kecil: Tempat Bertahan Dan Tumbuh.</p>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>