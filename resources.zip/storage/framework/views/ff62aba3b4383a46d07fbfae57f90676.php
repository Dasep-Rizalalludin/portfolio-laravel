

<?php $__env->startSection('title', 'Edit Buku'); ?>
<?php $__env->startSection('page-title', 'Edit Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Perbarui Buku</h2>
            <p class="panel-subtitle">Ubah detail buku yang sudah ada.</p>
        </div>
    </div>

    <form action="/admin/books/<?php echo e($book->id); ?>" method="POST" enctype="multipart/form-data" class="form-grid">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="form-label">Judul Buku</label>
            <input type="text" name="title" class="form-control" value="<?php echo e($book->title); ?>" required>
        </div>

        <div>
            <label class="form-label">Penulis</label>
            <input type="text" name="author" class="form-control" value="<?php echo e($book->author); ?>" required>
        </div>

        <div class="form-span">
            <label class="form-label">Link Google Drive</label>
            <input type="url" name="drive_link" class="form-control" value="<?php echo e($book->drive_link); ?>" required>
        </div>

        <div class="form-span">
            <label class="form-label">Cover Buku</label>
            <input type="file" name="cover_image" class="form-control">
            <?php if($book->cover_image): ?>
                <div class="mt-2">
                    <img src="<?php echo e(asset('storage/' . $book->cover_image)); ?>" alt="<?php echo e($book->title); ?>" style="max-height: 120px;" class="rounded">
                </div>
            <?php endif; ?>
        </div>

        <div class="form-actions">
            <a href="/admin/books" class="btn btn-light">Kembali</a>
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/admin/books/edit.blade.php ENDPATH**/ ?>