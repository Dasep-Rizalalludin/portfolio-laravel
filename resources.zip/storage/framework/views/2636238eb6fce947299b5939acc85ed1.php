

<?php $__env->startSection('title', 'Perpustakaan'); ?>

<?php $__env->startSection('content'); ?>
<h1>Perpustakaan</h1>

<?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($book->title); ?></h5>
            <p class="card-text"><?php echo e($book->author); ?></p>
            <a href="<?php echo e($book->drive_link); ?>" target="_blank" class="btn btn-primary">
                Baca Buku
            </a>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>Belum ada buku.</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/about/library/index.blade.php ENDPATH**/ ?>