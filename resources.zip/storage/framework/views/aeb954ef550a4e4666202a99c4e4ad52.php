

<?php $__env->startSection('title', 'Admin - Blog'); ?>
<?php $__env->startSection('page-title', 'Manajemen Blog'); ?>

<?php $__env->startSection('page-actions'); ?>
    <a href="<?php echo e(url('/admin/blog/create')); ?>" class="btn btn-primary">Tambah Artikel</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Daftar Artikel</h2>
            <p class="panel-subtitle">Kelola artikel blog yang tampil di halaman publik.</p>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Tanggal</th>
                    <th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->author); ?></td>
                    <td><?php echo e($post->published_at?->format('d M Y')); ?></td>
                    <td class="text-end">
                        <a href="<?php echo e(url('/admin/blog/' . $post->id . '/edit')); ?>" class="btn btn-outline-primary btn-sm">Edit</a>
                        <form action="<?php echo e(url('/admin/blog/' . $post->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Yakin hapus artikel ini?')">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted py-4">Belum ada artikel.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>