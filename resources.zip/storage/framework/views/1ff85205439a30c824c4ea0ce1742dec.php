<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    

    <!-- Bootstrap CDN -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/public.css')); ?>">

</head>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


<body class="<?php echo $__env->yieldContent('body-class'); ?>">

<?php if (! (request()->is('/'))): ?>
<nav class="navbar navbar-expand-lg site-nav">
    <div class="container">

        <!-- BRAND KIRI -->
        <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">Lelaki dan Hal - Hal...</a>

        <!-- HAMBURGER -->
        <button class="navbar-toggler" type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- MENU -->
        <div class="collapse navbar-collapse" id="navbarNav">

            <!-- MENU PUBLIK (KANAN) -->
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('home') ? 'active' : ''); ?>" href="<?php echo e(url('/home')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('about') ? 'active' : ''); ?>" href="<?php echo e(url('/about')); ?>">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('blog') ? 'active' : ''); ?>" href="<?php echo e(url('/blog')); ?>">Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('library') ? 'active' : ''); ?>" href="<?php echo e(url('/library')); ?>">Library</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('contact') ? 'active' : ''); ?>" href="<?php echo e(url('/contact')); ?>">Contact</a>
                </li>
            </ul>

            <!-- LOGOUT (PALING KANAN) -->
            <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(url('/logout')); ?>" class="ms-3">
                <?php echo csrf_field(); ?>
            </form>
            <?php endif; ?>

        </div>
    </div>
 </nav>
<?php endif; ?>



<main class="page-body">
    <?php echo $__env->yieldContent('content'); ?>
</main>

</body>
</html>
<?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>