

<?php $__env->startSection('title', 'Admin - Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('page-actions'); ?>
    <a href="<?php echo e(url('/admin/books/create')); ?>" class="btn btn-primary">Tambah Buku</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="stat-grid">
    <div class="stat-card">
        <h3><?php echo e($bookCount); ?></h3>
        <p>Total Buku</p>
    </div>
    <div class="stat-card">
        <h3><?php echo e($userCount); ?></h3>
        <p>Pengguna Terdaftar</p>
    </div>
    <div class="stat-card">
        <h3><?php echo e($recentBooks->count()); ?></h3>
        <p>Buku Terbaru (5 terakhir)</p>
    </div>
</div>

<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Navigasi Cepat</h2>
            <p class="panel-subtitle">Akses fitur utama admin panel dengan mudah.</p>
        </div>
    </div>

    <div class="quick-actions">
        <a href="<?php echo e(url('/admin/books')); ?>" class="quick-action">
            <div class="fw-semibold">Perpustakaan</div>
            <div class="text-muted small">Kelola daftar buku</div>
        </a>
        <a href="<?php echo e(url('/admin/blog')); ?>" class="quick-action">
            <div class="fw-semibold">Blog</div>
            <div class="text-muted small">Kelola artikel blog</div>
        </a>
    </div>
</div>

<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Buku Terbaru</h2>
            <p class="panel-subtitle">Update terakhir pada koleksi perpustakaan.</p>
        </div>
        <a href="<?php echo e(url('/admin/books')); ?>" class="btn btn-outline-secondary btn-sm">Lihat Semua</a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Drive</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->author); ?></td>
                    <td>
                        <a href="<?php echo e($book->drive_link); ?>" target="_blank" class="text-decoration-none">Lihat</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center text-muted py-4">Belum ada buku.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>