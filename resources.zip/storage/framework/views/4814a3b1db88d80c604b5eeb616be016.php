

<?php $__env->startSection('body-class', 'page-home'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">

            <!-- TEXT -->
            <div class="col-lg-6 hero-text">
                <h1 class="hero-name">
                    DASEP<br>RIZALLUDIN
                </h1>

                <p class="hero-desc">
                    Ia lahir di Sukabumi 8 Juli. Seorang lelaki beruntung yang kalo apa-apa suka sendiri, tapi kenyataan nya sering merepotkan orang lain. Hehe... Dalam menjalani hidupnya yang jauh dari orang tua. Baginya itu tidak masalah. Selagi bisa bernafas, dan masih bisa melihat senyum ibu. Sungguh hidup nya tetap baik-baik saja. Tidak bisa setebal skripsi menceritakan kisahnya, yang terpenting dia tidak tenggelam di lautan matamu. Oh iya, dia pun tidak akan berhenti di sini, dia akan selalu menulis hal yang memang seharusnya tidak di pikirkan. Dan mohon maaf jika bahasanya tidak baku seperti surat ke para pejabat, hehe... Jadi seperti itulah kira-kiranya. Oke deh, Terima kasih sudah berkunjung. Sampai jumpa di takdir selanjutnya.
                </p>

                <div class="hero-buttons">
                    <a href="<?php echo e(url('/about')); ?>" class="btn btn-hero-primary me-3">About Me</a>
                    <a href="<?php echo e(url('/blog')); ?>" class="btn btn-hero-secondary">Blog</a>
                </div>
            </div>

            <!-- IMAGE -->
            <div class="col-lg-6 text-center hero-image">
                <img src="<?php echo e(asset('images/fp.png')); ?>" alt="Profile">
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/home/index.blade.php ENDPATH**/ ?>