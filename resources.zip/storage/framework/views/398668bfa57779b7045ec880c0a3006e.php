

<?php $__env->startSection('title', $blogPost->title); ?>

<?php $__env->startSection('content'); ?>
<section class="blog-section">
    <div class="container">
        <div class="blog-header">
            <h1 class="blog-title"><?php echo e($blogPost->title); ?></h1>
            <p class="blog-subtitle"><?php echo e($blogPost->author); ?> - <?php echo e($blogPost->published_at?->format('d F Y')); ?></p>
        </div>

        <div class="blog-card">
            <div class="blog-body">
                <div><?php echo nl2br(e($blogPost->content)); ?></div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/blog/show.blade.php ENDPATH**/ ?>