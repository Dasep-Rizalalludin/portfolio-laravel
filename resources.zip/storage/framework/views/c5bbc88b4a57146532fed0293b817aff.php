

<?php $__env->startSection('title', 'Admin - Konten Website'); ?>
<?php $__env->startSection('page-title', 'Konten Website'); ?>

<?php $__env->startSection('page-actions'); ?>
    <a href="/home" class="btn btn-outline-secondary">Lihat Website</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Pengaturan Konten</h2>
            <p class="panel-subtitle">Perbarui teks utama yang tampil di halaman publik.</p>
        </div>
    </div>

    <form action="/admin/content" method="POST" class="form-grid">
        <?php echo csrf_field(); ?>

        <div class="form-span">
            <label class="form-label">Judul Hero</label>
            <input type="text" name="hero_title" class="form-control" value="<?php echo e(old('hero_title', $content['hero_title'] ?? '')); ?>" required>
            <?php $__errorArgs = ['hero_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-span">
            <label class="form-label">Subjudul Hero</label>
            <textarea name="hero_subtitle" rows="3" class="form-control" required><?php echo e(old('hero_subtitle', $content['hero_subtitle'] ?? '')); ?></textarea>
            <?php $__errorArgs = ['hero_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="form-label">Teks Tombol CTA</label>
            <input type="text" name="hero_cta" class="form-control" value="<?php echo e(old('hero_cta', $content['hero_cta'] ?? '')); ?>" required>
            <?php $__errorArgs = ['hero_cta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="form-label">Judul About</label>
            <input type="text" name="about_title" class="form-control" value="<?php echo e(old('about_title', $content['about_title'] ?? '')); ?>" required>
            <?php $__errorArgs = ['about_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-span">
            <label class="form-label">Deskripsi About</label>
            <textarea name="about_body" rows="4" class="form-control" required><?php echo e(old('about_body', $content['about_body'] ?? '')); ?></textarea>
            <?php $__errorArgs = ['about_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="form-label">Email Kontak</label>
            <input type="email" name="contact_email" class="form-control" value="<?php echo e(old('contact_email', $content['contact_email'] ?? '')); ?>" required>
            <?php $__errorArgs = ['contact_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="form-label">Nomor Telepon</label>
            <input type="text" name="contact_phone" class="form-control" value="<?php echo e(old('contact_phone', $content['contact_phone'] ?? '')); ?>" required>
            <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary">Simpan Perubahan</button>
        </div>
    </form>
</div>

<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Ringkasan</h2>
            <p class="panel-subtitle">Gunakan data ini untuk konsistensi konten di halaman lain.</p>
        </div>
    </div>

    <div class="content-card">
        <div class="row g-3">
            <div class="col-md-4">
                <div class="text-muted small">Hero CTA</div>
                <div class="fw-semibold"><?php echo e($content['hero_cta'] ?? '-'); ?></div>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Email</div>
                <div class="fw-semibold"><?php echo e($content['contact_email'] ?? '-'); ?></div>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Telepon</div>
                <div class="fw-semibold"><?php echo e($content['contact_phone'] ?? '-'); ?></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/admin/content/index.blade.php ENDPATH**/ ?>