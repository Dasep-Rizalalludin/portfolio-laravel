

<?php $__env->startSection('title', 'Tambah Buku'); ?>
<?php $__env->startSection('page-title', 'Tambah Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Form Buku</h2>
            <p class="panel-subtitle">Tambahkan buku baru ke koleksi.</p>
        </div>
    </div>

    <form action="<?php echo e(url('/admin/books')); ?>" method="POST" enctype="multipart/form-data" class="form-grid">
        <?php echo csrf_field(); ?>

        <div>
            <label class="form-label">Judul Buku</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div>
            <label class="form-label">Penulis</label>
            <input type="text" name="author" class="form-control" required>
        </div>

        <div class="form-span">
            <label class="form-label">Link Google Drive</label>
            <input type="url" name="drive_link" class="form-control" required>
        </div>

        <div class="form-span">
            <label class="form-label">Cover Buku</label>
            <input type="file" name="cover_image" class="form-control">
            <small class="text-muted">Format gambar JPG/PNG, maks 2MB.</small>
        </div>

        <div class="form-actions">
            <a href="<?php echo e(url('/admin/books')); ?>" class="btn btn-light">Kembali</a>
            <button class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/admin/books/create.blade.php ENDPATH**/ ?>