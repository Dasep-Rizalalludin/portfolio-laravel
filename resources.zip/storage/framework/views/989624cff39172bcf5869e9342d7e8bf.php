

<?php $__env->startSection('title', 'Admin Login - Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="login-container">
    <div class="login-card">
        <div class="login-header">
            <div class="login-logo">
                <i class="fas fa-shield-alt"></i>
            </div>
            <h1 class="login-title">Welcome</h1>
            <p class="login-subtitle">Sign in to access admin dashboard</p>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Login Failed!</strong> <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(url('/admin/login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label class="form-label" for="email">
                    <i class="fas fa-envelope"></i> Email Address
                </label>
                <div class="input-icon">
                    <i class="fas fa-user"></i>
                    <input 
                        type="email" 
                        name="email" 
                        id="email"
                        class="form-control" 
                        placeholder="admin@example.com"
                        value="<?php echo e(old('email')); ?>"
                        required 
                        autofocus
                    >
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">
                    <i class="fas fa-lock"></i> Password
                </label>
                <div class="input-icon">
                    <i class="fas fa-key"></i>
                    <input 
                        type="password" 
                        name="password" 
                        id="password"
                        class="form-control" 
                        placeholder="Enter your password"
                        required
                    >
                </div>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>