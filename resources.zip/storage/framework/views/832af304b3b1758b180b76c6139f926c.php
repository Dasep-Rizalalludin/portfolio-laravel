

<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('body-class', 'page-blog'); ?>

<?php $__env->startSection('content'); ?>
<section class="blog-section">
    <div class="container">
        <div class="blog-header">
            <h1 class="blog-title">BLOG-KU</h1>
            <p class="blog-subtitle">Jangan menyerah nanti kamu lelah</p>
        </div>

        <div class="blog-grid">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="blog-card">
                    <div class="blog-image">
                        <img src="<?php echo e($post->image_path ? asset('storage/' . $post->image_path) : asset('images/blog/madilog.jpg')); ?>" alt="<?php echo e($post->title); ?>">
                    </div>
                    <div class="blog-body">
                        <h3 class="blog-card-title"><?php echo e($post->title); ?></h3>
                        <div class="blog-meta"><?php echo e($post->author); ?> • <?php echo e($post->published_at?->format('d F Y')); ?></div>
                        <p class="blog-excerpt"><?php echo e(Str::limit(strip_tags($post->content), 100)); ?></p>
                        <a href="<?php echo e(route('blog.show', $post)); ?>" class="blog-btn">Baca Selengkapnya &gt;&gt;&gt;</a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted">Belum ada artikel.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/blog/index.blade.php ENDPATH**/ ?>