

<?php $__env->startSection('title', 'Perpustakaan'); ?>
<?php $__env->startSection('body-class', 'page-library'); ?>

<?php $__env->startSection('content'); ?>
<section class="library-section">
    <div class="container">
        <div class="library-header">
            <h1 class="library-title">MAU KEMANA? <br>MARI DUDUK DULU</h1>
            <p class="library-subtitle">Terima kasih telah sudi untuk melahap buku-buku ini</p>
        </div>

        <div class="library-grid">
            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="library-card">
                    <div class="library-thumb">
                        <img src="<?php echo e($book->cover_image ? asset('storage/' . $book->cover_image) : asset('images/library/cover.jpg')); ?>" alt="<?php echo e($book->title); ?>">
                    </div>
                    <div class="library-body">
                        <h3 class="library-card-title"><?php echo e($book->title); ?></h3>
                        <p class="library-author">Penulis : <?php echo e($book->author); ?></p>
                        <a href="<?php echo e($book->drive_link); ?>" target="_blank" class="library-btn">
                            Baca Selengkapnya &gt;&gt;&gt;
                        </a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-muted">Belum ada buku tersedia.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/library/index.blade.php ENDPATH**/ ?>