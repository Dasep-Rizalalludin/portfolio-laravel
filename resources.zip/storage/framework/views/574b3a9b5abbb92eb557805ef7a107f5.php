

<?php $__env->startSection('title', 'Admin - Buku'); ?>
<?php $__env->startSection('page-title', 'Kelola Buku'); ?>

<?php $__env->startSection('page-actions'); ?>
    <a href="<?php echo e(url('/admin/books/create')); ?>" class="btn btn-primary">Tambah Buku</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="panel-header">
        <div>
            <h2 class="panel-title">Daftar Buku</h2>
            <p class="panel-subtitle">Kelola koleksi buku yang tampil di halaman perpustakaan.</p>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>Cover</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Link</th>
                    <th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($book->cover_image): ?>
                            <img src="<?php echo e(asset('storage/' . $book->cover_image)); ?>" alt="<?php echo e($book->title); ?>" style="height: 48px; width: 48px; object-fit: cover;" class="rounded">
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="fw-semibold"><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->author); ?></td>
                    <td>
                        <a href="<?php echo e($book->drive_link); ?>" target="_blank" class="text-decoration-none">Lihat Drive</a>
                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(url('/admin/books/' . $book->id . '/edit')); ?>" class="btn btn-outline-primary btn-sm">Edit</a>
                        <form action="<?php echo e(url('/admin/books/' . $book->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-outline-danger btn-sm"
                                onclick="return confirm('Yakin hapus buku ini?')">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-muted py-4">Belum ada buku.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APK\xampp\htdocs\portfolio-laravel\resources\views/admin/books/index.blade.php ENDPATH**/ ?>